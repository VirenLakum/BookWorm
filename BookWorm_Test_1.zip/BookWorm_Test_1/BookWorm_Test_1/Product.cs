﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace BookWorm_Test_1
{
    [DataContract]
    public class Product
    {
        [DataMember]
        public int id { get; set; }

        [DataMember]
        public int type_id { get; set; }

        [DataMember]
        public int language_id { get; set; }

        [DataMember]
        public int category_id { get; set; }

        [DataMember]
        public string title { get; set; }

        [DataMember]
        public Decimal price { get; set; }

        [DataMember]
        public Decimal sellingPrice { get; set; }

        [DataMember]
        public Decimal specialPrice { get; set; }

        [DataMember]
        public DateTime saleFromDate { get; set; }

        [DataMember]
        public DateTime saleToDate { get; set; }

        [DataMember]
        public int daysOfSale { get; set; }

        [DataMember]
        public string shortDescription { get; set; }

        [DataMember]
        public string longDescription { get; set; }

        [DataMember]
        public string authors { get; set; }

        [DataMember]
        public DateTime releaseDate { get; set; }

        [DataMember]
        public Boolean isRentable { get; set; }

        [DataMember]
        public Boolean isInLibrary { get; set; }

        [DataMember]
        public Decimal rentAmount { get; set; }

        [DataMember]
        public int minimumRentDays { get; set; }

        [DataMember]
        public string publisher { get; set; }

        [DataMember]
        public string imagePath { get; set; }

    }
}