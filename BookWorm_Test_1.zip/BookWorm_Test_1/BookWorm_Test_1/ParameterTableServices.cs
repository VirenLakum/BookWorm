﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace BookWorm_Test_1
{
    public class ParameterTableServices
    {
        public static Boolean addParameter(Parameter param)
        {
            int result = 0;

            using (SqlConnection con = GetSqlConnection.getSqlConnection())
            {
                String insertStr = "insert into Product_Parameter values(@value)";

                SqlCommand cmd = new SqlCommand(insertStr, con);

                cmd.Parameters.AddWithValue("@value", param.value);

                con.Open();

                result = cmd.ExecuteNonQuery();
            }

            return result > 0 ? true : false;
        }
    }
}